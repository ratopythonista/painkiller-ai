from src import create_all

create_all()