from src.repository import Repository
from src.tables.patient import Patient

class PatientRepository(Repository):
    def insert(column: Patient):
        return super().insert(column)